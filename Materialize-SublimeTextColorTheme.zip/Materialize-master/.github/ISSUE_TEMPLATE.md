Thanks for submitting an issue! 

Before you continue, please check the past issues and make sure you aren't creating a duplicate. 

### Theme Issue:

1. OS:
2. Sublime Text version:
3. Materialize version:
4. Description of issue:
5. Steps to reproduce (if appropriate):
6. Screenshot of issue (if appropriate):

### Theme Request:

1. Theme Name:
2. Author Name:
3. Link to the color scheme:
4. License of color scheme:
